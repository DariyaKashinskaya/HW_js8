const html = document.querySelector('html')
html.setAttribute('lang', 'en');

const head = document.querySelector('head')
const body = document.querySelector('body')
const script = document.querySelector('script')

const title = document.createElement('title')
head.appendChild(title)
title.innerHTML = `HW_js8`;

const metaAuthor = document.createElement('meta')
metaAuthor.setAttribute('name', 'author')
metaAuthor.setAttribute('content', 'Kashinskaya Dariya')
head.appendChild(metaAuthor)

const metaCharset = document.createElement('meta')
metaCharset.setAttribute('charset', 'UTF-8')
head.appendChild(metaCharset)

const metaHttpEquiv = document.createElement('meta')
metaHttpEquiv.setAttribute('http-equiv', 'X-UA-Compatible')
metaHttpEquiv.setAttribute('content', 'IE=edge')
head.appendChild(metaHttpEquiv)

const metaViewport = document.createElement('meta')
metaViewport.setAttribute('name', 'viewport')
metaViewport.setAttribute('content', 'width=device-width, initial-scale=1')
head.appendChild(metaViewport)

const linkA = document.createElement('link')
linkA.setAttribute('rel', 'preconnect')
linkA.setAttribute('href', 'https://fonts.gstatic.com')
head.appendChild(linkA)

const linkB = document.createElement('link')
linkB.setAttribute('rel', 'stylesheet')
linkB.setAttribute('href', 'https://fonts.googleapis.com/css2?family=Arvo&family=Montserrat:wght@700&family=Open+Sans&display=swap')
head.appendChild(linkB)

const style = document.createElement('style')
head.appendChild(style)

head.appendChild(script)

const divA = document.createElement('div')
divA.classList.add('container')
divA.innerHTML = `
    <h1>Choose Your Option</h1>
    <p>But I must explain to you how all this mistaken idea of denouncing </p>
`
body.appendChild(divA)

const divB = document.createElement('div')
divB.classList.add('options')
divA.appendChild(divB)

const divC = document.createElement('div')
divC.classList.add('option')
divB.appendChild(divC)
const divD = document.createElement('div')
divD.classList.add('option')
divB.appendChild(divD)
divC.innerHTML = `
<p>FREELANCER</p>
<h1>Initially designed to</h1>
<p>But I must explain to you how all this mistaken idea of denouncing </p>
<button>START HERE</button>
`
divD.innerHTML = `
<p>STUDIO</p>
<h1>Initially designed to</h1>
<p>But I must explain to you how all this mistaken idea of denouncing </p>
<button>START HERE</button>
`

style.innerHTML = `*{
    padding: 0;
    margin: 0;
    box-sizing: border-box;
}
.container{
    max-width: 800px;
    margin: auto;
}
.container > p{
    font-size: 14px;
}
h1{
    font-family: Arvo;
    font-weight: 400;
    font-size: 36px;
    text-align: center;
    color: #212121;
    margin: 15px 0;
}
h1 + p{
    font-family: Open Sans;
    font-weight: 400;
    text-align: center;
    color: #9FA3A7;
    margin-bottom: 55px;
}
.options{
    display: grid;
    grid-template-columns: 1fr 1fr;

}
.option{
    text-align: center;
    padding: 80px 20%;
    border: #E8E9ED 1px solid;
    border-radius: 5px; 
    cursor: pointer;
}
.option:hover, .option:hover button{
    background-color: #8F75BE;
    transition: 0.5s;
    color: #FFFFFF;

}
button:hover{
    transform: scale(1.2);
    text-decoration: none;
}
.option:hover h1, .option:hover p{
    color: #FFFFFF;
    transition: 0.5s;
}
.option:hover p:first-child{
    color: #FFC80A;
    transition: 0.5s;
}
.option p{
    font-size: 12px;
}
.option p:first-child{
    font-family: Montserrat;
    font-weight: 700;
    color: #9FA3A7;
    letter-spacing: 2.4px;
}
button{
    background-color: #FFFFFF;
    width: 147px;
    height: 46px;   
    border: 3px solid #FFC80A;
    border-radius: 23px;
    font-family: Montserrat;
    font-weight: 700;
    font-size: 12px;
    color: #212121;
    letter-spacing: 2.4px;
    cursor: pointer;
}
@media (max-width: 900px){
    .container{
        max-width: 90%;
        margin: auto;
    }
}
@media (max-width: 760px){
    .option{
        padding: 8vh 5%;
    }
}
@media (max-width: 510px){
    .option{
        padding: 8vh 20%;
        width: 90%;
    }
    .options{
        display: flex;
        flex-direction: column;
        align-items: center;
    }
}
`